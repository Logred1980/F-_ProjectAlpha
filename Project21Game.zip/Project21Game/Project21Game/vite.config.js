﻿module.exports = {
  root: "wwwroot",
  build: {
    rollupOptions: {
      input: [
        "./Scripts/WebSharper/Project21Game/root.js"
      ]
    }
  }
}