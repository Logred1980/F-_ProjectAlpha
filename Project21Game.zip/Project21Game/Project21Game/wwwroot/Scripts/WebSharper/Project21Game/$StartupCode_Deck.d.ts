import Suit from "./CardTypes.Suit"
import Rank from "./CardTypes.Rank"
import { FSharpList_T } from "../WebSharper.StdLib/Microsoft.FSharp.Collections.FSharpList`1"
export default class $StartupCode_Deck {
  static oneDeck:FSharpList_T<{Suit:Suit,Rank:Rank}>;
}
