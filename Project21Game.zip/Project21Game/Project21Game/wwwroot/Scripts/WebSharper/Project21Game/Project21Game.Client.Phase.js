export function Playing(Item){
  return{$:1, $0:Item};
}
export let StartScreen={$:0};
