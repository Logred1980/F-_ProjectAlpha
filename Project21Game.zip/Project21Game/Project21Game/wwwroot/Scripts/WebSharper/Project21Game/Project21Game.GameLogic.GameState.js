export function New(PlayerHand, EnemyHand, Deck, GameOver, Winner, PlayerWins, EnemyWins){
  return{
    PlayerHand:PlayerHand, 
    EnemyHand:EnemyHand, 
    Deck:Deck, 
    GameOver:GameOver, 
    Winner:Winner, 
    PlayerWins:PlayerWins, 
    EnemyWins:EnemyWins
  };
}
