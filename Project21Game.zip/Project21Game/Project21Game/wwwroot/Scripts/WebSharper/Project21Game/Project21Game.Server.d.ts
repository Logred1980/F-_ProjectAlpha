import FSharpAsync from "../WebSharper.StdLib/Microsoft.FSharp.Control.FSharpAsync`1"
export function DoSomething(input:string):FSharpAsync<string>
