export { default as Runtime } from "../WebSharper.Core.JavaScript/Runtime.js"
export { EventQ2$211$36, AfterRenderQ2$227$42 } from "../WebSharper.UI.Templating.Runtime/WebSharper.UI.Templating.Runtime.Server.Handler.js"
export { Main } from "../Project21Game/Project21Game.Client.js"
