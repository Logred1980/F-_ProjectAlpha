export function isIRemotingService(x):x is IRemotingService
export default interface IRemotingService {
  get WebSharper_AspNetCore_IRemotingService$Handler()
}
