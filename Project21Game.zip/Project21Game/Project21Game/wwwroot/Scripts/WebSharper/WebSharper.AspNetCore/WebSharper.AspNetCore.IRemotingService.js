export function isIRemotingService(x){
  return"WebSharper_AspNetCore_IRemotingService$Handler"in x;
}
