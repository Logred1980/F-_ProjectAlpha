import IRemotingService_1 from "./WebSharper.AspNetCore.IRemotingService"
export function isIRemotingService(x):x is IRemotingService<T0>
export default interface IRemotingService<T0>extends IRemotingService_1 { }
