export function isIRemotingService(){
  return true;
}
