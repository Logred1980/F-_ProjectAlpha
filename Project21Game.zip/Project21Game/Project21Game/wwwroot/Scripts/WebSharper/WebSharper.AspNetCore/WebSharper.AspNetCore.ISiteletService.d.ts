export function isISiteletService(x):x is ISiteletService
export default interface ISiteletService {
  get WebSharper_AspNetCore_ISiteletService$Sitelet()
}
