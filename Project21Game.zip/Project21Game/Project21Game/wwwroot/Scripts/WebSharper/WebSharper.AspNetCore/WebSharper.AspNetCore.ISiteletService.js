export function isISiteletService(x){
  return"WebSharper_AspNetCore_ISiteletService$Sitelet"in x;
}
