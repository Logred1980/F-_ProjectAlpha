export function isIWebSharperService(x):x is IWebSharperService
export default interface IWebSharperService {
  WebSharper_AspNetCore_IWebSharperService$GetWebSharperMeta(a, b):[any, any, any]
  get WebSharper_AspNetCore_IWebSharperService$DefaultAssembly()
}
