import Router from "./WebSharper.Sitelets.Router`1"
import Router_1 from "./WebSharper.Sitelets.Router"
export default class $StartupCode_Router {
  static rDateTime:Router<number>;
  static rWildcard:Router<string>;
  static rBool:Router<boolean>;
  static rSingle:Router<number>;
  static rUInt64:Router<BigInt>;
  static rInt64:Router<BigInt>;
  static rUInt:Router<number>;
  static rUInt16:Router<number>;
  static rInt16:Router<number>;
  static rByte:Router<number>;
  static rSByte:Router<number>;
  static rDouble:Router<number>;
  static rInt:Router<number>;
  static rGuid:Router<string>;
  static rChar:Router<string>;
  static rString:Router<string>;
  static rRoot:Router_1;
  static Empty:Router<T0>;
}
