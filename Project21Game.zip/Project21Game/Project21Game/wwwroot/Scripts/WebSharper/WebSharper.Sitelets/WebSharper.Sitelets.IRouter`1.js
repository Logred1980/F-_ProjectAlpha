export function isIRouter(x){
  return"WebSharper_Sitelets_IRouter_1$Link"in x&&"WebSharper_Sitelets_IRouter_1$Route"in x;
}
