export function isIWebsite(x){
  return"WebSharper_Sitelets_IWebsite_1$Actions"in x&&"WebSharper_Sitelets_IWebsite_1$Sitelet"in x;
}
