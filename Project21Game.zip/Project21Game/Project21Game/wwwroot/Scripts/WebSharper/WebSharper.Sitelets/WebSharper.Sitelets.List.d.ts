import { FSharpList_T } from "../WebSharper.StdLib/Microsoft.FSharp.Collections.FSharpList`1"
import { FSharpOption } from "../WebSharper.StdLib/Microsoft.FSharp.Core.FSharpOption`1"
export function startsWith<T0>(s:FSharpList_T<T0>, l:FSharpList_T<T0>):FSharpOption<FSharpList_T<T0>>
