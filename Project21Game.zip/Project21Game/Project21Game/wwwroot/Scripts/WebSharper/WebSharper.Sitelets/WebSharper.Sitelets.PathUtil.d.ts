import { FSharpList_T } from "../WebSharper.StdLib/Microsoft.FSharp.Collections.FSharpList`1"
import FSharpMap from "../WebSharper.StdLib/Microsoft.FSharp.Collections.FSharpMap`2"
export function WriteLink(s:FSharpList_T<string>, q:FSharpMap<string, string>):string
export function WriteQuery(q:FSharpMap<string, string>):string
export function Concat(xs:FSharpList_T<string>):string
