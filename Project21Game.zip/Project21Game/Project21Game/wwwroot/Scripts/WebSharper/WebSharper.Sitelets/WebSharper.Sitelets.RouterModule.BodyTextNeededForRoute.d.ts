export default class BodyTextNeededForRoute extends Error {
  constructor()
}
