export function isIListArrayConverter(x):x is IListArrayConverter
export default interface IListArrayConverter {
  WebSharper_Sitelets_RouterModule_IListArrayConverter$OfArray(a)
  WebSharper_Sitelets_RouterModule_IListArrayConverter$ToArray(a)
}
