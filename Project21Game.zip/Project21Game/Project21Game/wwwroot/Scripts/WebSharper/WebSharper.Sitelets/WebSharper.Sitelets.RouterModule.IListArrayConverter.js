export function isIListArrayConverter(x){
  return"WebSharper_Sitelets_RouterModule_IListArrayConverter$OfArray"in x&&"WebSharper_Sitelets_RouterModule_IListArrayConverter$ToArray"in x;
}
