import Object from "../WebSharper.StdLib/System.Object"
import IListArrayConverter from "./WebSharper.Sitelets.RouterModule.IListArrayConverter"
export default class ListArrayConverter<T0>extends Object implements IListArrayConverter {
  WebSharper_Sitelets_RouterModule_IListArrayConverter$ToArray(l)
  WebSharper_Sitelets_RouterModule_IListArrayConverter$OfArray(a)
}
