export function isIOptionConverter(x){
  return"WebSharper_Sitelets_ServerInferredOperators_IOptionConverter$Get"in x&&"WebSharper_Sitelets_ServerInferredOperators_IOptionConverter$Some"in x;
}
