export function isIGeneric(x):x is IGeneric<T0, T1>
export default interface IGeneric<T0, T1>{
  WebSharper_Sitelets_Specialization_IGeneric_2$Run<T2>(a:T0):T1
}
