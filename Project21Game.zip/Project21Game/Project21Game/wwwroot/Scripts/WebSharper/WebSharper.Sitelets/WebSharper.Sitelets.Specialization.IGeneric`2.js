export function isIGeneric(x){
  return"WebSharper_Sitelets_Specialization_IGeneric_2$Run"in x;
}
