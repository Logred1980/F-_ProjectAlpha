import OutTextWriter from "./WebSharper.Console.OutTextWriter"
import ErrorTextWriter from "./WebSharper.Console.ErrorTextWriter"
export default class $StartupCode_Console {
  static outWriter:OutTextWriter;
  static errorWriter:ErrorTextWriter;
}
