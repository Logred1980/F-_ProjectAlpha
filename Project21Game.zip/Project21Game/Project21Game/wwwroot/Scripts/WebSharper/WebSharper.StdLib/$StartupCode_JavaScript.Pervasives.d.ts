import { FSharpList_T } from "./Microsoft.FSharp.Collections.FSharpList`1"
export default class Pervasives {
  static longMonths:FSharpList_T<string>;
  static shortMonths:FSharpList_T<string>;
  static longDays:FSharpList_T<string>;
  static shortDays:FSharpList_T<string>;
}
