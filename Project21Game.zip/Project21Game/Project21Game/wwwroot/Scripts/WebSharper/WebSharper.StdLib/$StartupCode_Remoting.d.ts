import IAjaxProvider from "./WebSharper.Remoting.IAjaxProvider"
export default class $StartupCode_Remoting {
  static AjaxProvider:IAjaxProvider;
  static EndPoint:string;
}
