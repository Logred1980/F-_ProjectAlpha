import ReadOnlySpan from "./System.ReadOnlySpan`1"
import { FSharpList_T } from "./Microsoft.FSharp.Collections.FSharpList`1"
export function Create<T0>(items:ReadOnlySpan<T0>):FSharpList_T<T0>
