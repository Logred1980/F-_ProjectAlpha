import { ofArray } from "./Microsoft.FSharp.Collections.ListModule.js"
export function Create(items){
  return ofArray(items);
}
