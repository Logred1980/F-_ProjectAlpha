import ReadOnlySpan from "./System.ReadOnlySpan`1"
import FSharpSet from "./Microsoft.FSharp.Collections.FSharpSet`1"
export function Create<T0>(items:ReadOnlySpan<T0>):FSharpSet<T0>
