import IObserver from "./System.IObserver`1"
export function observer<T0>(h:((a?:T0) => void)):IObserver<T0>
