import DelegateEvent from "./WebSharper.Control.DelegateEvent.DelegateEvent`1"
import Object from "./System.Object"
export default class FSharpDelegateEvent<T0>extends Object {
  event:DelegateEvent<T0>;
  constructor()
}
