import Event from "./WebSharper.Control.Event.Event`1"
import Object from "./System.Object"
export default class FSharpEvent<T0>extends Object {
  event:Event<T0>;
  constructor()
}
