import TaskBuilderBase from "./Microsoft.FSharp.Control.TaskBuilderBase"
export default class TaskBuilder extends TaskBuilderBase { }
