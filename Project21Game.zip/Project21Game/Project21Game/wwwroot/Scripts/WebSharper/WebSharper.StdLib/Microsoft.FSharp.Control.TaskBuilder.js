import TaskBuilderBase from "./Microsoft.FSharp.Control.TaskBuilderBase.js"
export default class TaskBuilder extends TaskBuilderBase { }
