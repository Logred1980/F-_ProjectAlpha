import Object from "./System.Object"
export default class TaskBuilderBase extends Object { }
