import Object from "./System.Object.js"
export default class TaskBuilderBase extends Object { }
