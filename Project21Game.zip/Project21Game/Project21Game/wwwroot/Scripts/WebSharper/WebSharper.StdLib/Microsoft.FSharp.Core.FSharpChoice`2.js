export function Choice1Of2(Item){
  return{$:0, $0:Item};
}
export function Choice2Of2(Item){
  return{$:1, $0:Item};
}
