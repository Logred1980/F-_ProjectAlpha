export function Choice1Of3(Item){
  return{$:0, $0:Item};
}
export function Choice2Of3(Item){
  return{$:1, $0:Item};
}
export function Choice3Of3(Item){
  return{$:2, $0:Item};
}
