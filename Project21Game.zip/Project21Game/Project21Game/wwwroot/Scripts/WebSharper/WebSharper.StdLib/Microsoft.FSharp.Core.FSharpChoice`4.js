export function Choice1Of4(Item){
  return{$:0, $0:Item};
}
export function Choice2Of4(Item){
  return{$:1, $0:Item};
}
export function Choice3Of4(Item){
  return{$:2, $0:Item};
}
export function Choice4Of4(Item){
  return{$:3, $0:Item};
}
