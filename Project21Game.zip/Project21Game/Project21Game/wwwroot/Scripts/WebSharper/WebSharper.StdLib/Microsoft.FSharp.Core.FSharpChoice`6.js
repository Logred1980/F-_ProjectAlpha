export function Choice1Of6(Item){
  return{$:0, $0:Item};
}
export function Choice2Of6(Item){
  return{$:1, $0:Item};
}
export function Choice3Of6(Item){
  return{$:2, $0:Item};
}
export function Choice4Of6(Item){
  return{$:3, $0:Item};
}
export function Choice5Of6(Item){
  return{$:4, $0:Item};
}
export function Choice6Of6(Item){
  return{$:5, $0:Item};
}
