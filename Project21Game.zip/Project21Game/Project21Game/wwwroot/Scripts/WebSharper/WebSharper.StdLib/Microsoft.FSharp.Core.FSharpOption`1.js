export function Some(Value){
  return{$:1, $0:Value};
}
