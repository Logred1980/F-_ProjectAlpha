export function New<T0>(contents)
export default interface FSharpRef<T0>{
  ["0"]:T0;
}
