export function New(contents){
  return[contents];
}
