import OutRef from "./WebSharper.OutRef`1"
export function TryParse(s:string, r:OutRef<number>):boolean
export function Parse(s:string):number
