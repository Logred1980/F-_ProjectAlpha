import Object from "./System.Object.js"
export default class Comparer extends Object {
  Compare0(x, y){
    return this.Compare_1(x, y);
  }
  Compare(x, y){
    return this.Compare_1(x, y);
  }
}
