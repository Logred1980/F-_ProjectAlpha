import Object from "./System.Object.js"
export default class EqualityComparer extends Object {
  CGetHashCode0(x){
    return this.GetHashCode_1(x);
  }
  CEquals0(x, y){
    return this.Equals_1(x, y);
  }
  CGetHashCode(x){
    return this.GetHashCode_1(x);
  }
  CEquals(x, y){
    return this.Equals_1(x, y);
  }
}
