export function isIComparer(x){
  return"Compare"in x;
}
