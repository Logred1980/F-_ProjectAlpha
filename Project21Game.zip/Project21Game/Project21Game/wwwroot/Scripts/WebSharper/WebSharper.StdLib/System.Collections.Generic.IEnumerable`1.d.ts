import IEnumerable_1 from "./System.Collections.IEnumerable"
export function isIEnumerable<T0>(x):x is IEnumerable<T0>
export default interface IEnumerable<T0>extends IEnumerable_1 { }
