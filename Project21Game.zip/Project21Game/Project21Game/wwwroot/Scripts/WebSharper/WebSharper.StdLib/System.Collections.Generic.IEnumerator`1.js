export function isIEnumerator(x){
  return"Current"in x;
}
