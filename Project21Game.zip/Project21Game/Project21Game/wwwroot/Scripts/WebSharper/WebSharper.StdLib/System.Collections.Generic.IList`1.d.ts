import ICollection from "./System.Collections.Generic.ICollection`1"
export function isIList<T0>(x):x is IList<T0>
export default interface IList<T0>extends ICollection<T0> { }
