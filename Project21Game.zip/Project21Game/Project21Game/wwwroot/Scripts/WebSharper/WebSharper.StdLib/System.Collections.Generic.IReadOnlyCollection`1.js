export function isIReadOnlyCollection(x){
  return"Count"in x;
}
