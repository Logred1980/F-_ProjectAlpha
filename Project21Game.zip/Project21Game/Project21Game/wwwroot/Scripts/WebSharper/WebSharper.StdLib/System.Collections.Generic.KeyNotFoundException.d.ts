export default class KeyNotFoundException extends Error {
  static New():KeyNotFoundException
  static New_1(message:string):KeyNotFoundException
  constructor(i:"New")
  constructor(i:"New_1", message:string)
}
