export function RemoveAll<T0>(this_1:(T0)[], pred:((a:T0) => boolean)):number
export function Remove<T0>(this_1:(T0)[], item:T0):boolean
