export function isIComparer(x):x is IComparer
export default interface IComparer {
  Compare0(a, b):number
}
