export function isIComparer(x){
  return"Compare0"in x;
}
