import IEnumerator from "./System.Collections.IEnumerator"
export function isIDictionaryEnumerator(x):x is IDictionaryEnumerator
export default interface IDictionaryEnumerator extends IEnumerator { }
