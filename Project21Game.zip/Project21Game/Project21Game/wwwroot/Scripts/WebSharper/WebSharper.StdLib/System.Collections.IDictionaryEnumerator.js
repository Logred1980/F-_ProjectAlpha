export function isIDictionaryEnumerator(){
  return true;
}
