export function isIEnumerable(x):x is IEnumerable
export default interface IEnumerable { }
