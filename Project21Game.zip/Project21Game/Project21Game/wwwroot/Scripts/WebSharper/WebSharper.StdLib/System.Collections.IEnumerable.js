export function isIEnumerable(x){
  return"GetEnumerator0"in x;
}
