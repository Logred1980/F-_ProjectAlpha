import ICollection from "./System.Collections.ICollection"
export function isIList(x):x is IList
export default interface IList extends ICollection { }
