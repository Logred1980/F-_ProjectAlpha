export function isIStructuralComparable(x){
  return"SCompareTo"in x;
}
