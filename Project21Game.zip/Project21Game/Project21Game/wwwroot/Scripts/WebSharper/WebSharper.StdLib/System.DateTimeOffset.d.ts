export function get_Now():MISSINGVARDateTimeOffset
export function get_DateTime(this_1:MISSINGVARDateTimeOffset):number
