import Object from "./System.Object"
export default class Exception extends Object { }
