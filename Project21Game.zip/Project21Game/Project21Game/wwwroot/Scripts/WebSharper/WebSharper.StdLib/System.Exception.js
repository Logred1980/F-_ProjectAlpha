import Object from "./System.Object.js"
export default class Exception extends Object { }
