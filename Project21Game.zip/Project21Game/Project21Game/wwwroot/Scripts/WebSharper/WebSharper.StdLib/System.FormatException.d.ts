export default class FormatException extends Error {
  static New():FormatException
  static New_1(message:string):FormatException
  constructor(i:"New")
  constructor(i:"New_1", message:string)
}
