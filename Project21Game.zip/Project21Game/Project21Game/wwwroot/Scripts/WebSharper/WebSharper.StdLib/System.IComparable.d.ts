export function isIComparable(x):x is IComparable
export default interface IComparable {
  CompareTo0(a):number
}
