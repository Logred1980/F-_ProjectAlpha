export function isIComparable(x){
  return"CompareTo0"in x;
}
