export function isIComparable(x){
  return"CompareTo"in x;
}
