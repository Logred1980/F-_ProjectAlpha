export function isIDisposable(x):x is IDisposable
export default interface IDisposable {
  Dispose():void
}
