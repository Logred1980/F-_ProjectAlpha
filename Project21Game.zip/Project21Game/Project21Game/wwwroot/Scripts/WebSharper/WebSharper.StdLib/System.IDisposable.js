export function isIDisposable(x){
  return"Dispose"in x;
}
