export function isIEquatable(x){
  return"EEquals"in x;
}
