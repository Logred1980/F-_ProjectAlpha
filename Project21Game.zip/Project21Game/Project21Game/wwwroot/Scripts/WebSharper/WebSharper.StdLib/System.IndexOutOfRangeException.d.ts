export default class IndexOutOfRangeException extends Error {
  static New():IndexOutOfRangeException
  static New_1(message:string):IndexOutOfRangeException
  constructor(i:"New")
  constructor(i:"New_1", message:string)
}
