import OutRef from "./WebSharper.OutRef`1"
export function TryParse(s:string, r:OutRef<BigInt>):boolean
export function Parse(s:string):BigInt
