export default class InvalidCastException extends Error {
  static New():InvalidCastException
  static New_1(message:string):InvalidCastException
  constructor(i:"New")
  constructor(i:"New_1", message:string)
}
