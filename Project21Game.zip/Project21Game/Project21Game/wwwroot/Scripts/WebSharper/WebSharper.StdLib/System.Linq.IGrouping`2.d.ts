export function isIGrouping(x):x is IGrouping<T0, T1>
export default interface IGrouping<T0, T1>{
  get System_Linq_IGrouping_2$Key():T0
}
