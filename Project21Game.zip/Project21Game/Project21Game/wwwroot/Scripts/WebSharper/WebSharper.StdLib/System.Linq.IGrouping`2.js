export function isIGrouping(x){
  return"System_Linq_IGrouping_2$Key"in x;
}
