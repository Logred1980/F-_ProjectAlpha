export function isIOrderedEnumerable(x){
  return"System_Linq_IOrderedEnumerable_1$CreateOrderedEnumerable"in x;
}
