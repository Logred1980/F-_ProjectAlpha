export default class Object {
  Equals(obj):boolean
  GetHashCode():number
}
