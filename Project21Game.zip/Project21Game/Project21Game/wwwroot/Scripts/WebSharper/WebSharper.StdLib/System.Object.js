export default class Object {
  Equals(obj){
    return this===obj;
  }
  GetHashCode(){
    return -1;
  }
}
