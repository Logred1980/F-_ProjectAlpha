export default class OperationCanceledException extends Error {
  ct;
  static New(ct){
    return new this("New", ct);
  }
  static New_1(message, inner, ct){
    return new this("New_1", message, inner, ct);
  }
  constructor(i, _1, _2, _3){
    let ct;
    if(i=="New"){
      ct=_1;
      i="New_1";
      _1="The operation was canceled.";
      _2=null;
      _3=ct;
    }
    if(i=="New_1"){
      const message=_1;
      const inner=_2;
      const ct_1=_3;
      super(message);
      this.inner=inner;
      this.ct=ct_1;
    }
  }
}
