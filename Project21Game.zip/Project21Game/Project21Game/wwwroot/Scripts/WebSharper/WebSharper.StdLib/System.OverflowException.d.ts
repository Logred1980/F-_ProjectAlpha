export default class OverflowException extends Error {
  static New():OverflowException
  static New_1(message:string):OverflowException
  constructor(i:"New")
  constructor(i:"New_1", message:string)
}
