export default class TaskCanceledException extends Error {
  static New():TaskCanceledException
  static New_1(message:string):TaskCanceledException
  constructor(i:"New")
  constructor(i:"New_1", message:string)
}
