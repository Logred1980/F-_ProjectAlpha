export default class TimeoutException extends Error {
  static New():TimeoutException
  static New_1(message:string):TimeoutException
  constructor(i:"New")
  constructor(i:"New_1", message:string)
}
