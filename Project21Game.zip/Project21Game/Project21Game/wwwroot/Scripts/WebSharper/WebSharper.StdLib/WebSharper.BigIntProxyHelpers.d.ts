export function ToBinaryStr(arr:number[]):string
export function ToBin(n:number):string
