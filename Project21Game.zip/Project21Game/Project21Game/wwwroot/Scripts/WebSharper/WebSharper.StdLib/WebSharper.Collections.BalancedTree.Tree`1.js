export function New(Node, Left, Right, Height, Count){
  return{
    Node:Node, 
    Left:Left, 
    Right:Right, 
    Height:Height, 
    Count:Count
  };
}
