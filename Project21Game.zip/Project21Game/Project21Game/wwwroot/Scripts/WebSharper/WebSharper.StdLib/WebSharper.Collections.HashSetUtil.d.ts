export function concat<T0>(o:((T0)[])[]):(T0)[]
