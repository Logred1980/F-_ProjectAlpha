import Comparer from "./System.Collections.Generic.Comparer`1"
export default class BaseComparer<T0>extends Comparer {
  Compare_1(x:T0, y:T0):number
}
