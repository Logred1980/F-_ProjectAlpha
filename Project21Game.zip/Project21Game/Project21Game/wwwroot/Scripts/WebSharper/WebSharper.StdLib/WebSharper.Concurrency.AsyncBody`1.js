export function New(k, ct){
  return{k:k, ct:ct};
}
