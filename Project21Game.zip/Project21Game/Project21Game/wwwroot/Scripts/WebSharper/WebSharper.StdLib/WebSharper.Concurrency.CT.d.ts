export function New(IsCancellationRequested, Registrations)
export default interface CT {
  c:boolean;
  r:((() => void))[];
}
