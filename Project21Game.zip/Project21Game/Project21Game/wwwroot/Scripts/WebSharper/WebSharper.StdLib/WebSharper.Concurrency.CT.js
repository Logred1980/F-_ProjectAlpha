export function New(IsCancellationRequested, Registrations){
  return{c:IsCancellationRequested, r:Registrations};
}
