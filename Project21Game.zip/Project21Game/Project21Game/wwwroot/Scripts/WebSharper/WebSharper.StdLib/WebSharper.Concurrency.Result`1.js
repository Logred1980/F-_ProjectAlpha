export function Cc(Item){
  return{$:2, $0:Item};
}
export function No(Item){
  return{$:1, $0:Item};
}
export function Ok(Item){
  return{$:0, $0:Item};
}
