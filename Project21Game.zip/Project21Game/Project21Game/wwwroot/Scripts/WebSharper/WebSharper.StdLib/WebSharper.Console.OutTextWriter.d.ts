import TextWriter from "./System.IO.TextWriter"
export default class OutTextWriter extends TextWriter {
  get Encoding()
}
