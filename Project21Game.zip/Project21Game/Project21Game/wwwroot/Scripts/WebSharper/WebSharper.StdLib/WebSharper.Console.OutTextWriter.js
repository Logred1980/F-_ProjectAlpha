import TextWriter from "./System.IO.TextWriter.js"
export default class OutTextWriter extends TextWriter {
  get Encoding(){
    return null;
  }
}
