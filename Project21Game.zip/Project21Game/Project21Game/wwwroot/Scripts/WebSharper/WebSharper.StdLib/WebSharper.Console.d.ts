import OutTextWriter from "./WebSharper.Console.OutTextWriter"
import ErrorTextWriter from "./WebSharper.Console.ErrorTextWriter"
export function outWriter():OutTextWriter
export function errorWriter():ErrorTextWriter
