import $StartupCode_Console from "./$StartupCode_Console.js"
export function outWriter(){
  return $StartupCode_Console.outWriter;
}
export function errorWriter(){
  return $StartupCode_Console.errorWriter;
}
