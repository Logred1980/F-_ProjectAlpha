export function Error(Item){
  return{$:1, $0:Item};
}
export function Message(Item){
  return{$:0, $0:Item};
}
export let Completed={$:2};
