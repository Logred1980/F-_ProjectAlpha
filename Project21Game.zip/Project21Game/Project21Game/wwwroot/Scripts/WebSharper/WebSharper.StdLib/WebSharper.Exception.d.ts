export function withInner<T0>(msg:string, inner:T0):Error
