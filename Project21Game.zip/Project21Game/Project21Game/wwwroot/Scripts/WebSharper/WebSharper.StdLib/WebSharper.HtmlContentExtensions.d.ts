import IControlBody from "./WebSharper.IControlBody"
export function IControlBody_SingleNode(node:Node):IControlBody
