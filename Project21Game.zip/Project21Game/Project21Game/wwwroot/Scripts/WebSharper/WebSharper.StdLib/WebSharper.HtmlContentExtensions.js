import SingleNode from "./WebSharper.HtmlContentExtensions.SingleNode.js"
export function IControlBody_SingleNode(node){
  return new SingleNode(node);
}
