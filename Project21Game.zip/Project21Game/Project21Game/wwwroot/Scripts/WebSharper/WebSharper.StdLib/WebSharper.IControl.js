export function isIControl(x){
  return"Body"in x;
}
