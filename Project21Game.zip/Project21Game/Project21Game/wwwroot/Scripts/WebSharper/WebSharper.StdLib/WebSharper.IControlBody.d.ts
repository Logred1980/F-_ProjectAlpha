export function isIControlBody(x):x is IControlBody
export default interface IControlBody {
  ReplaceInDom(a:Node):void
}
