export function isIControlBody(x){
  return"ReplaceInDom"in x;
}
