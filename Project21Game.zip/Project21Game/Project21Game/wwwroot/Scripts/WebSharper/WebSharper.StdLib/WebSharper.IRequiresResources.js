export function isIRequiresResources(x){
  return"WebSharper_IRequiresResources$Requires"in x;
}
