export function isIUniqueIdSource(x):x is IUniqueIdSource
export default interface IUniqueIdSource {
  WebSharper_IUniqueIdSource$NewId():string
}
