export function isIUniqueIdSource(x){
  return"WebSharper_IUniqueIdSource$NewId"in x;
}
