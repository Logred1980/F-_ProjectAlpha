export function isInRef(x){
  return"get"in x;
}
