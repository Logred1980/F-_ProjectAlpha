export function GetFieldValues(o):(any)[]
export function GetFieldNames(o):string[]
export function GetFields(o):([string, any])[]
