export default class NonStandardPromiseRejectionException extends Error {
  reason;
  get Reason()
  constructor(reason)
}
