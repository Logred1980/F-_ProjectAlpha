export function Defined<T0>(Item:T0):T0
export let Undefined;
export interface Undefined<T0>{
  $:0;
}
export interface Defined<T0>{
  $:1;
  $0:T0;
}
