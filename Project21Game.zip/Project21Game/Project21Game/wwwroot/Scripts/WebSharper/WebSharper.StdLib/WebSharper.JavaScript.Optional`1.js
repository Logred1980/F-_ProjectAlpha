export function Defined(Item){
  return{$:1, $0:Item};
}
export let Undefined={$:0};
