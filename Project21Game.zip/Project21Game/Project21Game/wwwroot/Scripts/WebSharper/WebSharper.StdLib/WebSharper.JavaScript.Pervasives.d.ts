import IEnumerable from "./System.Collections.Generic.IEnumerable`1"
export function GetJS<T0>(x, items:IEnumerable<string>):T0
export function NewFromSeq<T0>(fields:IEnumerable<[string, any]>):T0
