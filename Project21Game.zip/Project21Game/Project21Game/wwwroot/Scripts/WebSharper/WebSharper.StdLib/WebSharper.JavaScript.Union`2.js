export function Union2Of2(Item){
  return{$:1, $0:Item};
}
export function Union1Of2(Item){
  return{$:0, $0:Item};
}
