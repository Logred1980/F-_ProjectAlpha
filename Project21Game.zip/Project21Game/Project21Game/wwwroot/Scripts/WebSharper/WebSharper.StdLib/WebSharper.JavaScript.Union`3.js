export function Union3Of3(Item){
  return{$:2, $0:Item};
}
export function Union2Of3(Item){
  return{$:1, $0:Item};
}
export function Union1Of3(Item){
  return{$:0, $0:Item};
}
