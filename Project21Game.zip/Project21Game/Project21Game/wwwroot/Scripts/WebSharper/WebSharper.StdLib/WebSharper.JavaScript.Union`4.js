export function Union4Of4(Item){
  return{$:3, $0:Item};
}
export function Union3Of4(Item){
  return{$:2, $0:Item};
}
export function Union2Of4(Item){
  return{$:1, $0:Item};
}
export function Union1Of4(Item){
  return{$:0, $0:Item};
}
