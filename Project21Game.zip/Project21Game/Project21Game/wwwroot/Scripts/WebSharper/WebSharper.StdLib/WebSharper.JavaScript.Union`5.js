export function Union5Of5(Item){
  return{$:4, $0:Item};
}
export function Union4Of5(Item){
  return{$:3, $0:Item};
}
export function Union3Of5(Item){
  return{$:2, $0:Item};
}
export function Union2Of5(Item){
  return{$:1, $0:Item};
}
export function Union1Of5(Item){
  return{$:0, $0:Item};
}
