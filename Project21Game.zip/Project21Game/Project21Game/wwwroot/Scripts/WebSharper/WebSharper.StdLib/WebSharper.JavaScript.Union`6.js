export function Union6Of6(Item){
  return{$:5, $0:Item};
}
export function Union5Of6(Item){
  return{$:4, $0:Item};
}
export function Union4Of6(Item){
  return{$:3, $0:Item};
}
export function Union3Of6(Item){
  return{$:2, $0:Item};
}
export function Union2Of6(Item){
  return{$:1, $0:Item};
}
export function Union1Of6(Item){
  return{$:0, $0:Item};
}
