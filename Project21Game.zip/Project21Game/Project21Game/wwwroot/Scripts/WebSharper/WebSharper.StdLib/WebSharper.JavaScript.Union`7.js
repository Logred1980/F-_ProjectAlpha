export function Union7Of7(Item){
  return{$:6, $0:Item};
}
export function Union6Of7(Item){
  return{$:5, $0:Item};
}
export function Union5Of7(Item){
  return{$:4, $0:Item};
}
export function Union4Of7(Item){
  return{$:3, $0:Item};
}
export function Union3Of7(Item){
  return{$:2, $0:Item};
}
export function Union2Of7(Item){
  return{$:1, $0:Item};
}
export function Union1Of7(Item){
  return{$:0, $0:Item};
}
