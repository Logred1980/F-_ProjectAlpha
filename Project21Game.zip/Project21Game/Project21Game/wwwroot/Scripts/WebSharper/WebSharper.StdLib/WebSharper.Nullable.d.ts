export function getOrValue<T0>(x:T0, v:T0):T0
export function get(x)
