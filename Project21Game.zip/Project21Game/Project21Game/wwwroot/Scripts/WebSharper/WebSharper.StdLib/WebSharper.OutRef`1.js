export function isOutRef(x){
  return"set"in x;
}
