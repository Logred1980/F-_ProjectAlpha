export function CopyTo<T0>(a, array:(T0)[], index:number):void
export function Contains<T0>(a, el:T0):boolean
export function Clear(a):void
