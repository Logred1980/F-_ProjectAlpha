export function CopyTo<T0>(stack, array:(T0)[], index:number):void
export function Contains<T0>(stack, el:T0):boolean
export function Clear(stack):void
