export default class $StartupCode_Abbrev {
  static counter:number;
}
