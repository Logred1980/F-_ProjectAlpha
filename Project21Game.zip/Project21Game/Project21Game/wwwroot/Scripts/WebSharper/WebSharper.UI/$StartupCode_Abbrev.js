import { Lazy } from "../WebSharper.Core.JavaScript/Runtime.js"
let _c=Lazy((_i) => class $StartupCode_Abbrev {
  static {
    _c=_i(this);
  }
  static counter;
  static {
    this.counter=0;
  }
});
export default _c;
