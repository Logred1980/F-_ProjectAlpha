import Easing from "./WebSharper.UI.Easing"
export default class $StartupCode_Animation {
  static UseAnimations:boolean;
  static CubicInOut:Easing;
}
