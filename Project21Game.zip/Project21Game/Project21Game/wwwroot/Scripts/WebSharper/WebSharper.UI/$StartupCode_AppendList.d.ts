import AppendList from "./WebSharper.UI.AppendList`1"
export default class $StartupCode_AppendList {
  static Empty:AppendList<T0>;
}
