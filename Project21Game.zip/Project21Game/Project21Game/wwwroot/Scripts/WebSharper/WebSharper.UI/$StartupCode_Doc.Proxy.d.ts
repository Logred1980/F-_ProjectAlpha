export default class Proxy {
  static BatchUpdatesEnabled:boolean;
}
