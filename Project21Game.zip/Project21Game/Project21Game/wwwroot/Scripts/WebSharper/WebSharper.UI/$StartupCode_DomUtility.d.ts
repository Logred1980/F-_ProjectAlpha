export default class $StartupCode_DomUtility {
  static defaultWrap:[number, string, string];
  static wrapMap:{[a:string]:[number, string, string]};
  static rhtml:RegExp;
  static rtagName:RegExp;
  static rxhtmlTag:RegExp;
}
