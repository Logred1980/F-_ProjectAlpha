import KeyListenerSt from "./WebSharper.UI.Input.KeyListenerSt"
import MouseBtnSt from "./WebSharper.UI.Input.MouseBtnSt"
import MousePosSt from "./WebSharper.UI.Input.MousePosSt"
export default class $StartupCode_Input {
  static ActivateKeyListener:void;
  static KeyListenerState:KeyListenerSt;
  static ActivateButtonListener:void;
  static MouseBtnSt:MouseBtnSt;
  static MousePosSt:MousePosSt;
}
