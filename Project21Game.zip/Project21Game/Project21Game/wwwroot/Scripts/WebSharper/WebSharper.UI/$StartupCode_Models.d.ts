export default class $StartupCode_Models {
  static Default:{Encode:((a?:T0) => any),Decode:((a:any) => T0)};
}
