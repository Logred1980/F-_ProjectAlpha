import { Lazy } from "../WebSharper.Core.JavaScript/Runtime.js"
let _c=Lazy((_i) => class $StartupCode_Models {
  static {
    _c=_i(this);
  }
  static Default;
  static {
    this.Default={Encode:(v) => v, Decode:(v) => v};
  }
});
export default _c;
