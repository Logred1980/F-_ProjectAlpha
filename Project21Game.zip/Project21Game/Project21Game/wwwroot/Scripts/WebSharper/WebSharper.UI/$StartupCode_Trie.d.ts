import Trie from "./WebSharper.UI.Trie`2"
export default class $StartupCode_Trie {
  static Empty:Trie<T0, T1>;
}
