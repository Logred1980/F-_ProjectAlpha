import { Lazy } from "../WebSharper.Core.JavaScript/Runtime.js"
let _c=Lazy((_i) => class $StartupCode_Trie {
  static {
    _c=_i(this);
  }
  static Empty;
  static {
    this.Empty={$:1};
  }
});
export default _c;
