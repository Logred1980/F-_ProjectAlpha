import FSharpAsync from "../WebSharper.StdLib/Microsoft.FSharp.Control.FSharpAsync`1"
export function OnError(e:Error):void
export function StartTo<T0>(comp:FSharpAsync<T0>, k:((a?:T0) => void)):void
