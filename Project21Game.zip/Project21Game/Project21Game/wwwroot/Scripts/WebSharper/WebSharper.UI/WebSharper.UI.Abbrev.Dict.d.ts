import Dictionary from "../WebSharper.StdLib/System.Collections.Generic.Dictionary`2"
export function ToValueArray<T0, T1>(d:Dictionary<T0, T1>):(T1)[]
export function ToKeyArray<T0, T1>(d:Dictionary<T0, T1>):(T0)[]
