export function Id():string
export function Int():number
export function counter():number
export function set_counter(_1:number):number
