import FSharpAsync from "../WebSharper.StdLib/Microsoft.FSharp.Control.FSharpAsync`1"
export function StartProcessor(procAsync:FSharpAsync<void>):(() => void)
