import Slot from "./WebSharper.UI.Abbrev.Slot`2"
export function Create<T0, T1>(key:((a?:T0) => T1), value:T0):Slot<T0, T1>
