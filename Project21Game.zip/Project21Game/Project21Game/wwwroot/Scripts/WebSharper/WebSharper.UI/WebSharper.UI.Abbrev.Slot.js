import Slot from "./WebSharper.UI.Abbrev.Slot`2.js"
export function Create(key, value){
  return new Slot(key, value);
}
